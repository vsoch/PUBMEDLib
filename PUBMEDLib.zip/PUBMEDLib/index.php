<!doctype html>
<html lang="en-US">
<head>
	<meta charset="utf-8">
	<title>PUBMEDLib</title>
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Varela+Round">
        <link rel="stylesheet" href="style.css">

	<!--[if lt IE 9]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

</head>
<body>
	<div id="login">
		<h2><span class="fontawesome-star"></span>PUBMEDLib</h2>
		<form action="search.php" method="POST">
			<fieldset>
                               <!-- <p><label for="name">Search</label></p>--!>
				<p><input type="text" name="name" onBlur="if(this.value=='')this.value='brain'" onFocus="if(this.value=='brain')this.value=''"></p>
				<p><input type="submit" value="Search"></p>
			</fieldset>

		</form>

	</div> <!-- end login -->

</body>	
</html>
